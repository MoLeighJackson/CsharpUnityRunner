﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TiledBG : MonoBehaviour {

    public int textureSize = 32;
    public bool scaleHorizontally = true;
    public bool scaleVertically = true;

	void Start () {

        var newWidth = !scaleHorizontally ? 1 : Mathf.Ceil(Screen.width / (textureSize * CameraControl.scale));
        var newHeight = !scaleVertically ? 1 : Mathf.Ceil(Screen.height / (textureSize * CameraControl.scale));

        transform.localScale = new Vector3 (newWidth * textureSize, newHeight * textureSize, 1);

        // tell the material that it has a new vector scale
        GetComponent<Renderer>().material.mainTextureScale = new Vector3(newWidth, newHeight, 1);
    }
	
	
}
