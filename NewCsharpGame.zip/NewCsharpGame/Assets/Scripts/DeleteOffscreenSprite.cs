﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DeleteOffscreenSprite : MonoBehaviour {

    // determine (keep track of) when obstacle is off screen then destroy it (which makes game/code more efficient)
    public float offset = 16f; //for 16-bit game - how far off screen object needs to be before it's deleted

    private bool offscreen;
    private float offscreenX = 0;
    private Rigidbody2D body2d;
	
    void Awake()
    {
        body2d = GetComponent<Rigidbody2D>();
    }


	void Start () {
        offscreenX = (Screen.width/CameraControl.pixelsToUnits) / 2 + offset;
		
	}
	
	
	void Update () {
        // calculate when object is off screen
        var posX = transform.position.x;
        var dirX = body2d.velocity.x;

        if(Mathf.Abs(posX) > offscreenX) // condition checks if the value of the x position is greater than the offscreen x 
        {
            if(dirX < 0 && posX < -offscreenX)
            {
                offscreen = true;
            }else if (dirX > 0 && posX > offscreenX)
            {
                offscreen = true;
            }
        } else
        {
            offscreen = false;
        }

        if (offscreen)
        {
            OnOutofBounds();
        }
	}

    public void OnOutofBounds()
    {
        offscreen = false;
        GameObjectUtility.Destroy (gameObject);
    }
}
