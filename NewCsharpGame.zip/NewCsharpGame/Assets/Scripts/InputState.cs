﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class InputState : MonoBehaviour
{

  // is the player in motion or being stopped?
  // what is the player's absolute velocity?
  // is the player standing?
  
    // properties
    public bool actionButton;
    public float absValueX = 0f;
    public float absValueY = 0f;
    public bool standing;
    public float standingThreshold = 1;

    private Rigidbody2D body2d;

    //methods
    void Awake() 
    {
        body2d = GetComponent<Rigidbody2D>();

    }

    void Update()
    {

        actionButton = Input.anyKeyDown;
    }

    void FixedUpdate() { 

        absValueX = System.Math.Abs(body2d.velocity.x);
        absValueY = System.Math.Abs(body2d.velocity.y);
        standing = absValueX <= standingThreshold;
    }
}
